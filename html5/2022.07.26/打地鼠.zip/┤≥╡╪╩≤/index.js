var imgs = document.querySelectorAll(".i1")
console.log(imgs);
var table = document.getElementById("tab")
var defen = document.querySelector(".defen")
var start = document.querySelector(".start")
var stop1 = document.querySelector(".stop")
var zezhao = document.querySelector(".zezhao")
var box = document.querySelector(".zezhao .box")
var btn = document.querySelector(".btn")
var his = document.querySelector(".his")
var two1 = document.querySelector(".two")
var daojishi1 = document.querySelector(".daojishi")
var guodu1=document.querySelector(".zezao1 img")
var guodu2=document.querySelector(".zezao1 p")

var btn1=document.querySelector(".btn1")
// 初始化变量
var timer;
var timer1;
var flag = true;
var flag1=true;
// 遮罩
btn.addEventListener('click', function () {
    guodu1.style.display="none"
    guodu2.style.display="none"
    box.style.marginTop = '-800px'
    setTimeout(() => {
        zezhao.style.display = 'none'
    }, 1000);
})
// 倒计时
var num1 = 60;
function daojishi() {
    timer1 = setInterval(() => {
        num1--
        if (num1 < 0) {
            num1 = 0
            clearInterval(timer)
            if (his.innerHTML < defen.innerHTML) {
                his.innerHTML = defen.innerHTML
            }
        }
        daojishi1.innerHTML = `倒计时
         ${num1}
       `
    }, 1000);
}
//  出现
function f() {
    timer = setInterval(() => {
      
        var tm = parseInt(Math.round(Math.random() * 8))
        imgs[tm].style.display = "block"
    }, 1000);

}
// 再来一次
two1.onclick = function () {
    if(flag1){
        num1 = 60
        num = 0
         
        setInterval(timer, 1000)
        
        f()
        setInterval(timer1, 1000)
        if (his.innerHTML < defen.innerHTML) {
            his.innerHTML = defen.innerHTML
        }
        flag1=false
    }
    setTimeout(() => {
        flag1=true
    }, 60000);
   
}

//    开始
start.addEventListener('click', function () {
    guodu1.style.display="none"
    guodu2.style.display="none"
    if (flag) {
        f()
        daojishi()
        flag = false

    }
})
//  暂停  
stop1.addEventListener('click', function () {
    clearInterval(timer)
    clearInterval(timer1)
    flag = true
})
//   消失
setInterval(() => {
    Array.from(imgs).forEach(function (item, index) {
        if (imgs[index].style.display == "block") {

            setTimeout(() => {
                imgs[index].style.display = "none"
            }, 1000);
        }
    })
}, 100);
var num = 1
// 鼠标按下
table.onmousedown = function () {
    console.log(777);
    table.style.cursor = "url(./image/cursor-down.png),auto"


}
// 鼠标松开
table.onmouseup = function () {
    table.style.cursor = "url(./image/cursor.png),auto"
}
//    当前得分
Array.from(imgs).forEach(function (item, index) {
    item.onmousedown = function () {
        if (this.style.display == "block") {
            num++
            defen.innerHTML = `
                  ${num}
                `
        }
    }

})
btn1.addEventListener('click',function(){
    console.log(666);
       guodu1.style.display="block"
       guodu2.style.display="block"
       guodu1.style.animation="move1 3s forwards"
       guodu2.style.animation="move2 3s forwards"
})
guodu1.addEventListener('click',function(){
    guodu1.style.display="none"
    guodu2.style.display="none"
    guodu1.style.animation="move4 3s forwards"
    guodu1.style.animation="move3 3s forwards"

})













